<?php
$dbHost = 'localhost';
$dbName = 'db_webproject'; //ubah dengan nama database Anda
$dbUsername = 'root';
$dbPassword = '';
$mysqli = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
?>